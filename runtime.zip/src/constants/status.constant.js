export const STATUS = {
    SUCCESS: 'SUCCESS',
    FAILURE: 'FAILURE',
    PENDING: 'PENDING',
    RUNNING: 'RUNNING',
};