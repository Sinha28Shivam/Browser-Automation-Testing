import { runPlaywrightTest } from '../services/execution/playwrightRunner.service.js';
import { parseExecutionReport } from '../services/reportParser.service.js';

export const runTestWorkflow = async (filePath) => {
    const execution = await runPlaywrightTest(filePath);
    const report = parseExecutionReport(execution.stdout);

    return {
        execution,
        report
    };
};